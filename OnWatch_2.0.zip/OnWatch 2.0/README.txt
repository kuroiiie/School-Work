Project: OnWatch 2.0
Team:jcardozo@ucsc.edu, jeku@ucsc.edu, tmakwan@ucsc.edu, cfjiang@ucsc.edu


*************Important information****************************************
Click is the code for the pebble