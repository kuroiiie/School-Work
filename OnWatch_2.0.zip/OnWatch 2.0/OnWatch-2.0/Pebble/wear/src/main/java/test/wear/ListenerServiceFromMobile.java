package test.wear;

import android.content.Intent;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

public class ListenerServiceFromMobile extends WearableListenerService {
    private static final String MOBILE_PATH = "/from-mobile";

    @Override
    public void onMessageReceived(MessageEvent messageEvent){
        super.onMessageReceived(messageEvent);

        if(messageEvent.getPath().equals(MOBILE_PATH)){
            String threatStatus = new String(messageEvent.getData());

            Intent intent = new Intent(this,MainActivity.class);
            intent.putExtra("status",threatStatus);
            //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }
}