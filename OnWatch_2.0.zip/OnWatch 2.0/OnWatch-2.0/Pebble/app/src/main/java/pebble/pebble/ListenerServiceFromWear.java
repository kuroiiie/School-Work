package pebble.pebble;

import android.content.Intent;
import android.util.Log;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

public class ListenerServiceFromWear extends WearableListenerService {
    private static final String WEAR_PATH = "/from-wear";

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {
        super.onMessageReceived(messageEvent);

        if (messageEvent.getPath().equals(WEAR_PATH)) {
            String threatStatus = new String(messageEvent.getData());
            Log.d(WEAR_PATH, "It is listenting to wear");
            Intent intent = new Intent(this, StartActivity.class);
            intent.putExtra("status", threatStatus);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }
}

