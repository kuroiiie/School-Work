# PebbleGuard
onWatch - HackUCSC2016 

Created by:
Juan D. Cardozo
Garrett Stoll
Anthony Pan
Jerry Ku
Weibin Zhong


It's always dangerous to be by yourself when you are alone, especially at night. Without any friends or even witnesses to watch out for you, you are extremely vulnerable and your life is highly at risk. We wanted to build an application to tackle this problem, and with our new program, OnWatch, being by yourself isn't so bad after all.
 
 
 
 
